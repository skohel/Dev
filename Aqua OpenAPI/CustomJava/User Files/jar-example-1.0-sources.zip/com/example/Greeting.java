package com.example;

public class Greeting {

    private String greeting;

    public Greeting(String greeting) {
        this.greeting = greeting;
    }

    public String greet(String name) {
        return greeting + " " + name;
    }
}
